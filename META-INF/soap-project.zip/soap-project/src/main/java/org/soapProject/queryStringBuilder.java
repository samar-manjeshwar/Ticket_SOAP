package org.soapProject;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;

import xmlSch.*;

public class queryStringBuilder extends AbstractTransformer{

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {
		StringBuilder query = new StringBuilder();
		
		UpdateTicketRequest utr = (UpdateTicketRequest)src;
		if(utr.getCustomerId()!=null){
			query.append("set customer_id='"+utr.getCustomerId()+"', ");
		}
		if(utr.getUserId()!=null){
			query.append("user_id='"+utr.getUserId()+"', ");
		}
		if(utr.getGroupId()!=null){
			query.append("group_id='"+utr.getUserId()+"', ");
		}
		if(utr.getLabelId()!=null){
			query.append("label_id='"+utr.getLabelId()+"', ");
		}
		if(utr.getState()!=null){
			query.append("state='"+utr.getState()+"', ");
		}
		if(utr.getSubject()!=null){
			query.append("subject='"+utr.getSubject()+"', ");
		}
		if(utr.getReplyTo()!=null){
			query.append("reply_to='"+utr.getReplyTo()+"', ");
		}
		if(utr.getReplyCc()!=null){
			query.append("reply_cc='"+utr.getReplyCc()+"', ");
		}
		query.append("updated_at = NOW() ");
		query.append("where id="+utr.getId()+"");
		
		return "update Ticket set ".concat( query.toString());
	}

}
