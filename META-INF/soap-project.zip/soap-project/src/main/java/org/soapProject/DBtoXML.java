package org.soapProject;

import java.sql.Timestamp;
import java.util.LinkedList;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;
import org.mule.util.CaseInsensitiveHashMap;


public class DBtoXML extends AbstractTransformer{

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {
		LinkedList<Ticket> getAllTicketResponseList = new LinkedList<Ticket>();
		Ticket getAllTicketResponse;
		
		String[] part = new String[]{};
		for(CaseInsensitiveHashMap obj: (LinkedList<CaseInsensitiveHashMap>)src){
			getAllTicketResponse = new Ticket();
			String temp = (String) obj.get("label_ID");
			if(temp!=null){
				part = temp.split(",");
				getAllTicketResponse.setLabel_ID(part);
				//Json.add("label_ID",part);
			}
			else
			getAllTicketResponse.setLabel_ID(part);
			if(obj.get("ID")!=null){
				getAllTicketResponse.setID((int)obj.get("ID"));
			}
			else
				getAllTicketResponse.setID(00);
			getAllTicketResponse.setCustomer_ID((String)obj.get("customer_ID"));
			getAllTicketResponse.setUser_ID((String)obj.get("user_ID"));
			getAllTicketResponse.setGroup_ID((String)obj.get("group_ID"));
			getAllTicketResponse.setState((String)obj.get("state"));
			getAllTicketResponse.setSubject((String)obj.get("subject"));
			getAllTicketResponse.setReply_To((String)obj.get("reply_to"));
			getAllTicketResponse.setReply_Cc((String)obj.get("reply_cc"));
			if(obj.get("spam")!=null)
				getAllTicketResponse.setSpam((boolean)obj.get("spam"));
			if(obj.get("trash")!=null)
				getAllTicketResponse.setTrash((boolean)obj.get("trash"));
			if(obj.get("updated_at")!=null)
				getAllTicketResponse.setUpdated_At((Timestamp)obj.get("updated_at"));
			if(obj.get("created_at")!=null)
				getAllTicketResponse.setCreated_At((Timestamp)obj.get("created_at"));
			
			getAllTicketResponseList.add(getAllTicketResponse);
			
		}
		
		return getAllTicketResponseList;
	}

}

