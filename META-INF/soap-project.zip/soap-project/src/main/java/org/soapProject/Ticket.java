package org.soapProject;

import java.sql.Timestamp;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
class Ticket{
	
	public int ID;
	@XmlElement
	public String customer_ID;
	@XmlElement
	public String user_ID;
	@XmlElement
	public String group_ID;
	@XmlElement
	public String[] labelID;
	@XmlElement
	public String state;
	@XmlElement
	public String subject;
	@XmlElement
	public String reply_to;
	@XmlElement
	public String reply_cc;
	@XmlElement
	public boolean spam;
	@XmlElement
	public boolean trash;
	@XmlElement
	public Timestamp updated_at;
	@XmlElement
	public Timestamp created_at;

	
	public void setID(int ID){
		this.ID = ID;
	}
	public void setCustomer_ID(String customer_ID){
		this.customer_ID = customer_ID;
	}
	public void setUser_ID(String user_ID){
		this.user_ID = user_ID;
	}
	public void setGroup_ID(String group_ID){
		this.group_ID = group_ID;
	}
	public void setLabel_ID(String[] label_ID){
		this.labelID = label_ID;
	}
	public void setState(String state){
		this.state = state;
	}
	public void setSubject(String subject){
		this.subject = subject;
	}
	public void setReply_To(String reply_To){
		this.reply_to = reply_To;
	}
	public void setReply_Cc(String reply_Cc){
		this.reply_cc = reply_Cc;
	}
	public void setSpam(boolean spam){
		this.spam = spam;
	}
	public void setTrash(boolean trash){
		this.trash = trash;
	}
	public void setUpdated_At(Timestamp updated_At){
		this.updated_at = updated_At;
	}
	public void setUpdated_At(String updated_at){
		Object temp = (Object)updated_at;
		this.updated_at = (Timestamp)temp;
	}
	public void setCreated_At(Timestamp created_At){
		this.created_at = created_At;
	}
	public void setCreated_At(String created_at){
		Object temp = (Object)created_at;
		this.created_at = (Timestamp)temp;
	}
}
