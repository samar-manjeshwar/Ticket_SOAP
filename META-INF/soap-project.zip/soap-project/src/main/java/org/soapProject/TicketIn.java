package org.soapProject;


import java.sql.Timestamp;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
class TicketIn{
	
	public int ID;
	
	public String customer_ID;

	public String user_ID;
	
	public String group_ID;
	
	public String[] labelID;
	
	public String state;
	
	public String subject;
	
	public String reply_to;
	
	public String reply_cc;
	
	public boolean spam;
	
	public boolean trash;

	
	
	public void setID(int ID){
		this.ID = ID;
	}
	@XmlElement
	public void setCustomer_ID(String customer_ID){
		this.customer_ID = customer_ID;
	}
	@XmlElement
	public void setUser_ID(String user_ID){
		this.user_ID = user_ID;
	}
	@XmlElement
	public void setGroup_ID(String group_ID){
		this.group_ID = group_ID;
	}
	@XmlElement
	public void setLabel_ID(String[] label_ID){
		this.labelID = label_ID;
	}
	@XmlElement
	public void setState(String state){
		this.state = state;
	}
	@XmlElement
	public void setSubject(String subject){
		this.subject = subject;
	}
	@XmlElement
	public void setReply_To(String reply_To){
		this.reply_to = reply_To;
	}
	@XmlElement
	public void setReply_Cc(String reply_Cc){
		this.reply_cc = reply_Cc;
	}
	@XmlElement
	public void setSpam(boolean spam){
		this.spam = spam;
	}
	@XmlElement
	public void setTrash(boolean trash){
		this.trash = trash;
	}
	
}
